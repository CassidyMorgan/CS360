package com.example.myweighttrackingapp;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.Toast;

public class GridScreen extends AppCompatActivity {

    EditText date, currentWeight, goalWeight;
    Button add, update, delete, view, logout, SMS;
    Switch notification;
    DBHelper UserDB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_grid_screen);

        date = findViewById(R.id.etDate);
        currentWeight = findViewById(R.id.etCurrentWeight);
        goalWeight = findViewById(R.id.etGoalWeight);

        add = findViewById(R.id.buttonAdd);
        update = findViewById(R.id.buttonUpdate);
        delete = findViewById(R.id.buttonDelete);
        view = findViewById(R.id.buttonView);
        logout = findViewById(R.id.buttonLogout);
        SMS = findViewById(R.id.buttonSMS);

        UserDB = new DBHelper(this);

        // If add button is clicked, add data to database
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String dateTXT = date.getText().toString();
                String currentWeightTXT = currentWeight.getText().toString();
                String goalWeightTXT = goalWeight.getText().toString();

                Boolean checkAddData = UserDB.insertUserDetails(dateTXT, currentWeightTXT, goalWeightTXT);
                if(checkAddData == true){
                    Toast.makeText(GridScreen.this, "New Entry Added", Toast.LENGTH_SHORT).show();
                }
                else{
                    Toast.makeText(GridScreen.this, "New Entry NOT Added", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // If update button is clicked update data in database
        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String dateTXT = date.getText().toString();
                String currentWeightTXT = currentWeight.getText().toString();
                String goalWeightTXT = goalWeight.getText().toString();

                Boolean checkUpdatedData = UserDB.updateUserDetails(dateTXT, currentWeightTXT, goalWeightTXT);
                if(checkUpdatedData == true){
                    Toast.makeText(GridScreen.this, "Entry Updated", Toast.LENGTH_SHORT).show();
                }
                else{
                    Toast.makeText(GridScreen.this, "Entry NOT updated", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // If delete button is clicked delete data in database
        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String dateTXT = date.getText().toString();

                Boolean checkDeletedData = UserDB.deleteUserDetails(dateTXT);
                if(checkDeletedData == true){
                    Toast.makeText(GridScreen.this, "Entry Deleted", Toast.LENGTH_SHORT).show();
                }
                else{
                    Toast.makeText(GridScreen.this, "Entry NOT Deleted", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // If view button is clicked, view data in database
        view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Cursor res = UserDB.getUserDetails();
                if(res.getCount()==0){
                    Toast.makeText(GridScreen.this, "No Existing Entry", Toast.LENGTH_SHORT).show();
                    return;
                }
                StringBuffer buffer = new StringBuffer();
                while (res.moveToNext()){
                    buffer.append("Date :"+res.getString(0)+"\n");
                    buffer.append("Current Weight :"+res.getString(1)+"\n");
                    buffer.append("Goal Weight :"+res.getString(2)+"\n\n");
                }

                AlertDialog.Builder builder = new AlertDialog.Builder(GridScreen.this);
                builder.setCancelable(true);
                builder.setTitle("User Entries");
                builder.setMessage(buffer.toString());
                builder.show();
            }
        });

        // If logout button is clicked, return to MainActivity (login screen)
        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent logoutIntent = new Intent(GridScreen.this, MainActivity.class);
                startActivity(logoutIntent);
            }
        });

        // If SMS button is clicked, go to notification screen
        SMS.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent notificationIntent = new Intent(GridScreen.this, NotificationScreen.class);
                startActivity(notificationIntent);
            }
        });
    }
}


