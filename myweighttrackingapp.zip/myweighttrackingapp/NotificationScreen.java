package com.example.myweighttrackingapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class NotificationScreen extends AppCompatActivity {

    private EditText PhoneNumber;
    private Button Enter, Back;
    private TextView Message;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notification);

        ActivityCompat.requestPermissions(NotificationScreen.this, new String[]{Manifest.permission.SEND_SMS, Manifest.permission.READ_SMS}, PackageManager.PERMISSION_GRANTED);

        PhoneNumber = findViewById(R.id.etPhoneNumber);
        Enter = findViewById(R.id.buttonEnter);
        Back = findViewById(R.id.buttonBack);
        Message = findViewById(R.id.tvGoalReached);

        // If enter is clicked, enter phone number for SMS messages
        Enter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String number = PhoneNumber.getText().toString();
                String message = Message.getText().toString();

                SmsManager mySMSManager = SmsManager.getDefault();
                mySMSManager.sendTextMessage(number,null,message,null,null);
            }
        });

        // If back button is clicked, return to previous screen (GridScreen)
        Back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent backIntent = new Intent(NotificationScreen.this, GridScreen.class);
                startActivity(backIntent);
            }
        });
    }
}