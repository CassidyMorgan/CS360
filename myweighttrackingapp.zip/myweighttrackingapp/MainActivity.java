package com.example.myweighttrackingapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private EditText username, password;
    private Button login;
    private TextView message, register;
    private int counter = 5;
    private DBHelper Database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        username = (EditText) findViewById(R.id.editTextUsername);
        password = (EditText) findViewById(R.id.editTextPassword);
        login = (Button) findViewById(R.id.buttonLogin);
        message = (TextView) findViewById(R.id.textViewNumOfAttempts);
        message.setText("Remaining attempts: 5");
        Database = new DBHelper(this);
        register = (TextView)findViewById(R.id.textViewRegister);

        // If register is clicked, go to register screen (RegisterActivity)
        register.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent registerIntent = new Intent(getApplicationContext(), RegisterActivity.class);
                startActivity(registerIntent);
            }
        });

        // If login button is clicked, check validity of credentials and if valid, login.
        login.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                String user = username.getText().toString();
                String pass = password.getText().toString();

                if (user.equals("") || pass.equals("")) {
                    Toast.makeText(MainActivity.this, "Field(s) missing data", Toast.LENGTH_SHORT).show();
                }
                else {
                    Boolean checkUserNPass = Database.checkUserNPassExists(user, pass);
                    if (checkUserNPass == true) {
                        Toast.makeText(MainActivity.this, "Login Successful", Toast.LENGTH_SHORT).show();
                        Intent loginIntent = new Intent(MainActivity.this, GridScreen.class);
                        startActivity(loginIntent);
                    }
                    else {
                        Toast.makeText(MainActivity.this, "Credentials Invalid", Toast.LENGTH_SHORT).show();
                        counter--;
                        message.setText("Remaining attempts: " + String.valueOf(counter) + ". If you are a new user and want to create an account, click Register Here.");
                        if (counter == 0) {
                            login.setEnabled(false);
                        }
                    }
                }
            }
        });
    }
}
