package com.example.myweighttrackingapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

public class RegisterActivity extends AppCompatActivity implements OnClickListener {
    private EditText Username, Password, ConfirmPassword;
    private Button Register;
    private TextView AlreadyRegistered;
    private DBHelper Database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        Username = (EditText)findViewById(R.id.editTextUsername);
        Password = (EditText)findViewById(R.id.editTextPassword);
        Register = (Button) findViewById(R.id.buttonRegister);
        AlreadyRegistered = (TextView)findViewById(R.id.textViewAlreadyRegistered);
        ConfirmPassword = (EditText)findViewById(R.id.editTextConfirmPassword);
        Database = new DBHelper(this);

        // If Already Registered is clicked, navigate to MainActivity (login screen)
        AlreadyRegistered.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent loginIntent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(loginIntent);
            }
        });

        // If register button is clicked, check to see if fields are null and if not, add information to database
        // and go to MainActivity (login screen).
        Register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String user = Username.getText().toString();
                String pass = Password.getText().toString();
                String confpass = ConfirmPassword.getText().toString();

                if(user.equals("") || pass.equals("") || confpass.equals(""))
                    Toast.makeText(RegisterActivity.this, "Field(s) missing data", Toast.LENGTH_SHORT).show();
                else{
                    if(pass.equals(confpass)){
                        Boolean checkuser = Database.checkUsernameExists(user);
                        if(checkuser==false){
                            Boolean insert = Database.insertData(user, pass);
                            if(insert==true) {
                                Toast.makeText(RegisterActivity.this, "You are now registered", Toast.LENGTH_SHORT).show();
                                Intent loginIntent = new Intent(getApplicationContext(), MainActivity.class);
                                startActivity(loginIntent);
                            }
                            else{
                                Toast.makeText(RegisterActivity.this, "Registration failed", Toast.LENGTH_SHORT).show();
                            }
                        }
                        else{
                            Toast.makeText(RegisterActivity.this, "User already exists. Please Login.", Toast.LENGTH_SHORT).show();
                        }
                    }
                    else{
                        Toast.makeText(RegisterActivity.this, "Passwords do not match", Toast.LENGTH_SHORT).show();
                    }
                }

            }
        });
    }

    @Override
    public void onClick(View v) {

    }
}