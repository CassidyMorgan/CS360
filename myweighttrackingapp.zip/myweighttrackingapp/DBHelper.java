package com.example.myweighttrackingapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DBHelper extends SQLiteOpenHelper {
    public static final String DBName = "Login.db";

    public DBHelper(Context context) {
        super(context, "Login.db", null, 2);
    }

    // Create tables for users and for user details
    @Override
    public void onCreate(SQLiteDatabase UserDB) {
        UserDB.execSQL("create Table users(username TEXT primary key, password TEXT)");
        UserDB.execSQL("create Table UserDetails(date TEXT primary key, currentWeight TEXT, goalWeight TEXT, users_username TEXT, FOREIGN KEY(users_username) REFERENCES users(username))");
    }

    // Drop tables if they already exist
    @Override
    public void onUpgrade(SQLiteDatabase UserDB, int oldVersion, int newVersion) {
        UserDB.execSQL("drop Table if exists users");
        UserDB.execSQL("drop Table if exists UserDetails");

        onCreate(UserDB);
    }

    // Insert username and password function
    public Boolean insertData(String username, String password){
        SQLiteDatabase UserDB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("username", username);
        contentValues.put("password", password);
        long result = UserDB.insert("users", null, contentValues);
        if(result==-1)
            return false;
        else
            return true;
    }

    // Check if username exists function
    public Boolean checkUsernameExists(String username){
        SQLiteDatabase UserDB = this.getWritableDatabase();
        Cursor cursor = UserDB.rawQuery("Select * from users where username = ?", new String[] {username});
        if(cursor.getCount()>0)
            return true;
        else
            return false;
    }

    // Check if username and password exists in database function
    public Boolean checkUserNPassExists(String username, String password){
        SQLiteDatabase UserDB = this.getWritableDatabase();
        Cursor cursor = UserDB.rawQuery("Select * from users where username = ? and password = ?", new String[] {username, password});
        if(cursor.getCount()>0)
            return true;
        else
            return false;
    }

    // Insert user details function
    public Boolean insertUserDetails(String date, String currentWeight, String goalWeight){
        SQLiteDatabase UserDB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("date", date);
        contentValues.put("currentWeight", currentWeight);
        contentValues.put("goalWeight", goalWeight);
        long result = UserDB.insert("UserDetails", null, contentValues);
        if(result==-1){
            return false;
        }
        else{
            return true;
        }
    }

    // Update user details function
    public Boolean updateUserDetails(String date, String currentWeight, String goalWeight){
        SQLiteDatabase UserDB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("currentWeight", currentWeight);
        contentValues.put("goalWeight", goalWeight);
        Cursor cursor = UserDB.rawQuery("Select * from UserDetails where date = ?", new String[] {date});
        if(cursor.getCount()>0) {
            long result = UserDB.update("UserDetails", contentValues, "date=?", new String[] {date});
            if (result == -1) {
                return false;
            } else {
                return true;
            }
        }
        else{
            return false;
        }
    }

    // Delete user details function
    public Boolean deleteUserDetails(String date){
        SQLiteDatabase UserDB = this.getWritableDatabase();
        Cursor cursor = UserDB.rawQuery("Select * from UserDetails where date = ?", new String[]{date});
        if(cursor.getCount()>0) {
            long result = UserDB.delete("UserDetails", "date=?", new String[]{date});
            if (result == -1) {
                return false;
            } else {
                return true;
            }
        }
        else{
            return false;
        }
    }

    // Get user details function
    public Cursor getUserDetails(){
        SQLiteDatabase UserDB = this.getWritableDatabase();
        Cursor cursor = UserDB.rawQuery("Select * from UserDetails", null);
        return cursor;
    }
}
